public class AustralianKelpie extends Dog {
   

    public AustralianKelpie(){

    }
    
    public AustralianKelpie(String Name, int Age, String ukuran, String ColorFur, String TypeofFur, String Gender, boolean Makansehari){
        super(Name, Age, ukuran, ColorFur, TypeofFur, Gender, Makansehari);
    }
}
