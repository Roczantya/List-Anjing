public class Pomeranian extends Dog {
    

    public Pomeranian(){

    }
    public Pomeranian(String Name, int Age, String ukuran, String ColorFur, String TypeofFur, String Gender, boolean Makansehari){
        super(Name, Age, ukuran, ColorFur, TypeofFur, Gender, Makansehari);
    }
}