import java.util.ArrayList;

public class Petshop {
    public static void main(String[] args) {
        ArrayList<Dog> Listanjing = new ArrayList<Dog>();
        Listanjing.add(new AiredaleTerrier("Rina", 3, "Sedang", "Coklat-putih", "Lurus", "Male", true));
        Listanjing.add(new BichonFrise("Snowy", 3, "Kecil", "Putih", "Keriting", "Female", true));
        Listanjing.add(new Doberman("Bruno", 5, "Besar", "Hitam", "Kasar", "Male", true));
        Listanjing.add(new Bulldog("Tuna", 4, "Besar", "putih", "lurus", "Female", true));
        Listanjing.add(new Pomeranian("Fluffy", 2, "Kecil", "Coklat", "Keriting", "Female", true));
        Listanjing.add(new AlaskanMalamute("Buddy", 4, "Besar", "Abu-abu", "Panjang", "Male", true));
        Listanjing.add(new ContinentalToySpaniel("Luna", 3, "Sedang", "Hitam", "Lurus", "Female", true));
        Listanjing.add(new BluePicardySpaniel("Lina", 3, "Sedang", "Hitam", "Lurus", "Female", true));
        Listanjing.add(new AustralianKelpie("Lisa", 4, "Besar", "Hitam-putih", "Keriting", "Male", true));
        Listanjing.add(new PetitBrabançon("Bobby", 2, "Kecil", "Coklat", "Keriting", "Male", true));

        System.out.println("List of Dogs in the Petshop:");
        System.out.println("--------------------------------------------------------------");
        System.out.printf("%-15s %-10s %-10s %-15s %-15s %-10s %-10s\n", "Name", "Age", "Size", "Color", "Fur Type", "Gender", "Eats Daily");
        System.out.println("--------------------------------------------------------------");
        for (Dog dog : Listanjing) {
            System.out.printf("%-15s %-10d %-10s %-15s %-15s %-10s %-10b\n", dog.getName(), dog.getAge(), dog.getUkuran(), dog.getColorFur(), dog.getTypeoFur(), dog.getGender(), dog.getMakanSehari());
        }
        System.out.println("--------------------------------------------------------------");

    }
} 
