//Anjing kecil
public class AiredaleTerrier extends Dog{
   
    public AiredaleTerrier(){

    }
    
    public AiredaleTerrier(String Name, int Age, String ukuran, String ColorFur, String TypeofFur, String Gender, boolean Makansehari){
        super(Name, Age, ukuran, ColorFur, TypeofFur, Gender, Makansehari);
       
    
    }
}


    