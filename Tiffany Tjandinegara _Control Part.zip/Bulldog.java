//Anjing Besar
public class Bulldog extends Dog{

    public Bulldog(){

    }
    public Bulldog(String Name, int Age, String ukuran, String ColorFur, String TypeofFur, String Gender, boolean Makansehari){
        super(Name, Age, ukuran, ColorFur, TypeofFur, Gender, Makansehari);
    }
}
