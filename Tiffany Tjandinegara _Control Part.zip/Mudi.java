//Anjing Kecil
public class Mudi extends Dog {
   
    public Mudi(){

    }
    public Mudi(String Name, int Age, String ukuran, String ColorFur, String TypeofFur, String Gender, boolean Makansehari){
        super(Name, Age, ukuran, ColorFur, TypeofFur, Gender, Makansehari);
    
    }
}
