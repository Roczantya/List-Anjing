//Anjing Sedang
public class BluePicardySpaniel extends Dog{
    
    public BluePicardySpaniel(){
        
    }

    public BluePicardySpaniel(String Name, int Age, String ukuran, String ColorFur, String TypeofFur, String Gender, boolean Makansehari){
        super(Name, Age, ukuran, ColorFur, TypeofFur, Gender, Makansehari);
    }
}
