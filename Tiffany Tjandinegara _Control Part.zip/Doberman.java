// Anjing Besar
public class Doberman extends Dog{
    

    public Doberman(){

    }
    
    public Doberman(String Name, int Age, String ukuran, String ColorFur, String TypeofFur, String Gender, boolean Makansehari){
        super(Name, Age, ukuran, ColorFur, TypeofFur, Gender, Makansehari);
    }
}